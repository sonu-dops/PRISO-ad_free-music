/**
 * PRISO Web Push Service Worker
 * Handles background push notifications, badge counts, and deep link navigation for web users.
 */

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  if (!event.data) return;

  let payload = {
    title: 'Priso Sanctuary 💌',
    body: 'You have a new update from your partner.',
    icon: '/logo192.png',
    badge: '/logo192.png',
    tag: 'priso_web_push',
    data: { url: '/chat' },
  };

  try {
    const json = event.data.json();
    if (json.notification) {
      payload.title = json.notification.title || payload.title;
      payload.body = json.notification.body || payload.body;
      payload.icon = json.notification.icon || payload.icon;
      payload.badge = json.notification.badge || payload.badge;
      payload.tag = json.notification.tag || payload.tag;
    }
    if (json.data) {
      payload.data = { ...payload.data, ...json.data };
      if (json.data.title) payload.title = json.data.title;
      if (json.data.body) payload.body = json.data.body;
      if (json.data.url) payload.data.url = json.data.url;
    }
  } catch (e) {
    // Plain text fallback
    payload.body = event.data.text() || payload.body;
  }

  const options = {
    body: payload.body,
    icon: payload.icon || '/logo192.png',
    badge: payload.badge || '/logo192.png',
    tag: payload.tag || 'priso_web_push',
    renotify: true,
    data: payload.data,
    vibrate: [100, 50, 100],
    actions: [
      { action: 'open', title: 'Open Sanctuary' },
      { action: 'reply', title: 'Reply', type: 'text', placeholder: 'Type a reply...' },
    ],
  };

  event.waitUntil(self.registration.showNotification(payload.title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const data = event.notification.data || {};
  const targetUrl = data.url || '/chat';
  const replyText = event.reply;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          if (replyText && client.postMessage) {
            client.postMessage({ type: 'PRISO_NOTIFICATION_REPLY', conversationId: data.conversationId, text: replyText });
          }
          client.navigate(replyText ? `${targetUrl}?replied=true` : targetUrl);
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        const dest = replyText ? `${targetUrl}?replyText=${encodeURIComponent(replyText)}` : targetUrl;
        return self.clients.openWindow(dest);
      }
    })
  );
});
